import sqlite3
from relational_algebra import *
class Expressions:
    # You can manually define expressions here or load from the uploaded file
    # Example Query: Find Databases conference and their rankings
    sample_query = Projection(
            ThetaJoin(
                Selection(
                    Relation("field_conference"),
                    Equals("field", "Databases")
                ),
                Relation("conference_ranking"),
                Equals("field_conference.conference", "conference_ranking.conf_abbr")
            ),
            ["conference_ranking.conf_abbr", "conference_ranking.rank"]
        )

    # Uncomment and define other expressions
    # expression1 = ...
    
    # expression2 = ...
    
    # expression3 = ...
    
    # expression4 = ...
    
    # expression5 = ...

    # Example query execution
    sql_con = sqlite3.connect('sample220P.db')  # Ensure the uploaded database is loaded here
    result = sample_query.evaluate(sql_con=sql_con)
    print(result.rows)
